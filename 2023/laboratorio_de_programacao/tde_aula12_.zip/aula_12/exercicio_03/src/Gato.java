public class Gato extends Animal {
    @Override
    public void comer() {
        System.out.println("Gato comendo...");
    }
    @Override
    public void dormir() {
        System.out.println("Gato dormindo...");
    }
    @Override
    public void mover() {
        System.out.println("Gato se movendo...");
    }
}
