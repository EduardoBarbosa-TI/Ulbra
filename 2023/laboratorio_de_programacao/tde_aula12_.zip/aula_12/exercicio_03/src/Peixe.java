public class Peixe extends Animal {
    @Override
    public void comer() {
        System.out.println("Peixe comendo...");
    }

    @Override
    public void dormir() {
        System.out.println("Peixe dormindo...");
    }

    @Override
    public void mover() {
        System.out.println("Peixe se movendo...");
    }
}
