public abstract class Animal {
    public void comer(){}
    public void dormir(){}
    public void mover(){};
}


