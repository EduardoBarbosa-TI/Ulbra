public class ImpressoraMatricial extends Impressora{
    @Override
    public void imprimir() {
        System.out.println("Impressora matricial sendo utilizada para impressão");
    }
    @Override
    public void escanear() {
        System.out.println("Impressora matricial sendo utilizada para escanear");
    }
}
