public class ImpressoraJatoTinta extends Impressora{
    @Override
    public void imprimir() {
        System.out.println("Impressora jato a tinta sendo utilizada para impressão");
    }
    @Override
    public void escanear() {
        System.out.println("Impressora jato a tinta sendo utilizada para escanear");
    }
}
