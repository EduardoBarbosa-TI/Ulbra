public abstract class Impressora {
    public void imprimir(){}
    public void escanear(){}
}
