public class ImpressoraLaser extends Impressora{
    @Override
    public void imprimir() {
        System.out.println("Impressora laser sendo utilizada para impressão");
    }

    @Override
    public void escanear() {
        System.out.println("Impressora laser sendo utilizada para escanear");
    }
}
