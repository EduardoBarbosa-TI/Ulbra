public abstract class  Produto {
    public void calcularPreco(int qtdProduto){}
    public void exibirDetalhes(){}
}
