public abstract class Funcionario {
    public void calcularSalario(){}
    public void realizarTarefa(){}
}
