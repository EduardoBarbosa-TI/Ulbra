public abstract class DispositivoArmazenamento {
    public void lerDados(){}
    public void gravarDados(){}
}
