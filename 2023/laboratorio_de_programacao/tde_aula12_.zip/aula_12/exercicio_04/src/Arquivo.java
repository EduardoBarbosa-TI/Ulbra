public abstract class Arquivo {
    public void abrir(){}

    public void fechar(){}
}
