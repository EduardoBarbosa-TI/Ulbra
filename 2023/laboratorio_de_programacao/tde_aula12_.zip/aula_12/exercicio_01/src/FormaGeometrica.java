public abstract class FormaGeometrica {
    public void calcularArea(){
        System.out.println("Calculando Área...");
    }
    public void calcularPerimetro(){
        System.out.println("Calculando Perímetro...");
    }
}
