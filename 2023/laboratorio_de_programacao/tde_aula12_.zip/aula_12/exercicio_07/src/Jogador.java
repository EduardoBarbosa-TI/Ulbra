public abstract class Jogador{
    public void atacar(){}
    public void defender(){}
}
