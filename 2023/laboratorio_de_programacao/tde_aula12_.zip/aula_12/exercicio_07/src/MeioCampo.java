public class MeioCampo extends Jogador{
    @Override
    public void atacar() {
        System.out.println("Meio campo atacando o time adversário");
    }

    @Override
    public void defender() {
        System.out.println("Meio campo defendendo o seu time");
    }
}
