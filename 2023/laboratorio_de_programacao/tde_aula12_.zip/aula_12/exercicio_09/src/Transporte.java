public abstract class Transporte {
    public void carregar(){}
    public void descarregar(){}
}
