public class Navio extends Transporte{
    @Override
    public void carregar() {
        System.out.println("Navio carregado!");

    }
    @Override
    public void descarregar() {
        System.out.println("Navio descarregado!");
    }
}
